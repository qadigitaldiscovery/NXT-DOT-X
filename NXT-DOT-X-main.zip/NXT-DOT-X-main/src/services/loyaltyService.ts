
// This file is kept for backward compatibility
// It re-exports everything from the modular loyalty service
export * from './loyalty';
