
import React from 'react';
import PersonasHub from '@/components/tech-hub/PersonasHub';

const TechHubPersonas = () => {
  return <PersonasHub />;
};

export default TechHubPersonas;
