import React from "react";
import MasterDash from "../../src/pages/MasterDash";

function App() {
  return (
    <div>
      <MasterDash />
    </div>
  );
}

export default App;